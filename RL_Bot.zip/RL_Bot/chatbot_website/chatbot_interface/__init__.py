default_app_config = 'chatbot_interface.chatbotmanager.ChatbotManager'
